import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatTableDataSource } from '@angular/material/table';


@Component({
  selector: 'app-job-folder',
  templateUrl: './job-folder.component.html',
  styleUrls: ['./job-folder.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*', display: 'table-row' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class JobFolderComponent implements OnInit {
  columnsToDisplay = ['button', 'folder', 'customername', 'dateofvisit', 'shortdescription', 'agreement', 'action'];
  dataSource: MatTableDataSource<Element>;
  constructor() {
    this.dataSource = new MatTableDataSource();
  }


  agreement = new FormControl();
  agreementList: string[] = ['Agreement One', 'Agreement Two', 'Agreement Three', 'Agreement Four', 'Agreement Five', 'Agreement Six'];
  folder = new FormControl();
  folderList: string[] = ['Folder One', 'Folder Two', 'Folder Three', 'Folder Four', 'Folder Five', 'Folder Six'];
  // displayedColumns = ['folder', 'agreement', 'createdby', 'action'];
  // dataSource = ELEMENT_DATA;

  expandedElement: any;

  ngOnInit(): void {
    this.dataSource.data = data;
  }

}

export interface Element {
  folder: string;
  customername: string;
  address: string;
  dateofvisit: string;
  shortdescription: string;
  agreement: string;
  createdby: string;
}


// export interface Element {
//   Name: string;
//   Phone: string;
//   Address: string;
//   Company: string;
//   Category: string;
//   Subcategory: string;
// }


// const data: Element[] = [
//   { folder: 'Folder One', customername: '', address: '', dateofvisit: '', shortdescription: '', agreement: 'Agreement One, Agreement Two ', createdby: 'Steve Smith' },
//   { folder: 'Folder Two', customername: '', address: '', dateofvisit: '', shortdescription: '', agreement: 'Agreement Two, Agreement Three', createdby: 'Joseph William' },
//   { folder: 'Folder Three', customername: '', address: '', dateofvisit: '', shortdescription: '', agreement: 'Agreement Five', createdby: 'Robert Henry' },
//   { folder: 'Folder Four ', customername: '', address: '', dateofvisit: '', shortdescription: '', agreement: 'Agreement Three', createdby: 'Steve Smith' },
//   { folder: 'Folder Five', customername: '', address: '', dateofvisit: '', shortdescription: '', agreement: 'Agreement Two', createdby: 'Joseph William' },
//   { folder: 'Folder Six', customername: '', address: '', dateofvisit: '', shortdescription: '', agreement: 'Agreement Five, Agreement Nine', createdby: 'Robert Henry' },
//   { folder: 'Folder Seven', customername: '', address: '', dateofvisit: '', shortdescription: '', agreement: 'Agreement Three, Agreement Eleven', createdby: 'Joseph William' },
//   { folder: 'Folder Eight', customername: '', address: '', dateofvisit: '', shortdescription: '', agreement: 'Agreement Two, Agreement Eight', createdby: 'Robert Henry' },
//   { folder: 'Folder Nine', customername: '', address: '', dateofvisit: '', shortdescription: '', agreement: 'Agreement Six, Agreement Twelve', createdby: 'Joseph William' },
//   { folder: 'Folder Ten', customername: '', address: '', dateofvisit: '', shortdescription: '', agreement: 'Agreement Two, Agreement Five', createdby: 'Robert Henry' },
//   { folder: 'Folder Eleven', customername: '', address: '', dateofvisit: '', shortdescription: '', agreement: 'Agreement Seven', createdby: 'Steve Smith' },
//   { folder: 'Folder Twelve', customername: '', address: '', dateofvisit: '', shortdescription: '', agreement: 'Agreement Ten', createdby: 'Robert Henry' },
// ];

const data: Element[] = [
  { folder: 'Folder One', customername: 'Steve Smith', address: '132, My Street, Kingston, New York 12401', dateofvisit: 'October 10, 2021', shortdescription: 'Plumbing Work', agreement: 'Agreement One, Agreement Two ', createdby: 'Steve Smith' },
  { folder: 'Folder Two', customername: 'Joseph William', address: '3425 Stone Street, Apt. 2A, Jacksonville, FL 39404', dateofvisit: 'October 05, 2021', shortdescription: 'Painter Work', agreement: 'Agreement Two, Agreement Three', createdby: 'Joseph William' },
  { folder: 'Folder Three', customername: 'Robert Henry', address: '223 Center Street, Venus, New York 10001.', dateofvisit: 'October 02, 2021', shortdescription: 'Contruction Work', agreement: 'Agreement Five', createdby: 'Robert Henry' },
  { folder: 'Folder Four ', customername: 'Steve Smith', address: '132, My Street, Kingston, New York 12401', dateofvisit: 'October 10, 2021', shortdescription: 'Plumbing Work', agreement: 'Agreement Three', createdby: 'Steve Smith' },
  { folder: 'Folder Five', customername: 'Joseph William', address: '3425 Stone Street, Apt. 2A, Jacksonville, FL 39404', dateofvisit: 'October 05, 2021', shortdescription: 'Painter Work', agreement: 'Agreement Two', createdby: 'Joseph William' },
  { folder: 'Folder Six', customername: 'Robert Henry', address: '223 Center Street, Venus, New York 10001.', dateofvisit: 'October 02, 2021', shortdescription: 'Contruction Work', agreement: 'Agreement Five, Agreement Nine', createdby: 'Robert Henry' },
  { folder: 'Folder Seven', customername: 'Steve Smith', address: '132, My Street, Kingston, New York 12401', dateofvisit: 'October 10, 2021', shortdescription: 'Plumbing Work', agreement: 'Agreement Three, Agreement Eleven', createdby: 'Joseph William' },
  { folder: 'Folder Eight', customername: 'Joseph William', address: '3425 Stone Street, Apt. 2A, Jacksonville, FL 39404', dateofvisit: 'October 05, 2021', shortdescription: 'Painter Work', agreement: 'Agreement Two, Agreement Eight', createdby: 'Robert Henry' },
  { folder: 'Folder Nine', customername: 'Robert Henry', address: '223 Center Street, Venus, New York 10001.', dateofvisit: 'October 02, 2021', shortdescription: 'Contruction Work', agreement: 'Agreement Six, Agreement Twelve', createdby: 'Joseph William' },
  { folder: 'Folder Ten', customername: 'Steve Smith', address: '132, My Street, Kingston, New York 12401', dateofvisit: 'October 10, 2021', shortdescription: 'Plumbing Work', agreement: 'Agreement Two, Agreement Five', createdby: 'Robert Henry' },
  { folder: 'Folder Eleven', customername: 'Joseph William', address: '3425 Stone Street, Apt. 2A, Jacksonville, FL 39404', dateofvisit: 'October 05, 2021', shortdescription: 'Painter Work', agreement: 'Agreement Seven', createdby: 'Steve Smith' },
  { folder: 'Folder Twelve', customername: 'Robert Henry', address: '223 Center Street, Venus, New York 10001.', dateofvisit: 'October 02, 2021', shortdescription: 'Contruction Work', agreement: 'Agreement Ten', createdby: 'Robert Henry' },
];