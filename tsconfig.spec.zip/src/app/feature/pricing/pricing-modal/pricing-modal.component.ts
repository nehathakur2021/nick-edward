import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pricing-modal',
  templateUrl: './pricing-modal.component.html',
  styleUrls: ['./pricing-modal.component.scss']
})
export class PricingModalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
