import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-job-packet-modal',
  templateUrl: './job-packet-modal.component.html',
  styleUrls: ['./job-packet-modal.component.scss']
})
export class JobPacketModalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
