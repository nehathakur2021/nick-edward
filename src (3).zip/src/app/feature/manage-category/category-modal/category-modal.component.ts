import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-category-modal',
  templateUrl: './category-modal.component.html',
  styleUrls: ['./category-modal.component.scss']
})
export class CategoryModalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
