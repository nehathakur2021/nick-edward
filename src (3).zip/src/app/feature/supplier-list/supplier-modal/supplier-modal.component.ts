import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supplier-modal',
  templateUrl: './supplier-modal.component.html',
  styleUrls: ['./supplier-modal.component.scss']
})
export class SupplierModalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
